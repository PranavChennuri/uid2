/*
  # Create saved designs table

  1. New Tables
    - `saved_designs`
      - `id` (uuid, primary key)
      - `user_id` (uuid) - References auth.users
      - `name` (text)
      - `furniture_data` (jsonb) - Array of placed furniture with positions
      - `thumbnail_url` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policies for authenticated users to:
      - Create their own designs
      - Read their own designs
      - Update their own designs
      - Delete their own designs
*/

CREATE TABLE IF NOT EXISTS saved_designs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  name text NOT NULL,
  furniture_data jsonb NOT NULL,
  thumbnail_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE saved_designs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can create their own designs"
  ON saved_designs
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read their own designs"
  ON saved_designs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own designs"
  ON saved_designs
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own designs"
  ON saved_designs
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);