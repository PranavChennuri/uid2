/*
  # Add sample furniture items

  1. Sample Data
    - Insert sample furniture items with proper UUIDs
    - Include various categories: Seating, Tables, Storage
    - Use placeholder model URLs and real thumbnail images from Pexels
    - Set appropriate scales and default rotations

  2. Data Safety
    - Use ON CONFLICT DO NOTHING to prevent duplicate insertions
    - Safe to run multiple times
*/

-- Insert sample furniture items with proper UUIDs
INSERT INTO furniture_items (id, name, category, model_url, thumbnail_url, scale, default_rotation) VALUES
  (
    gen_random_uuid(),
    'Modern Accent Chair',
    'Seating',
    '/models/chair.glb',
    'https://images.pexels.com/photos/586763/pexels-photo-586763.jpeg?auto=compress&cs=tinysrgb&w=400',
    1.0,
    ARRAY[0.0, 0.0, 0.0]
  ),
  (
    gen_random_uuid(),
    'Glass Coffee Table',
    'Tables',
    '/models/table.glb',
    'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=400',
    1.0,
    ARRAY[0.0, 0.0, 0.0]
  ),
  (
    gen_random_uuid(),
    'Comfortable Sofa',
    'Seating',
    '/models/sofa.glb',
    'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=400',
    1.2,
    ARRAY[0.0, 0.0, 0.0]
  ),
  (
    gen_random_uuid(),
    'Wooden Dining Chair',
    'Seating',
    '/models/dining-chair.glb',
    'https://images.pexels.com/photos/1148955/pexels-photo-1148955.jpeg?auto=compress&cs=tinysrgb&w=400',
    0.9,
    ARRAY[0.0, 0.0, 0.0]
  ),
  (
    gen_random_uuid(),
    'Modern Bookshelf',
    'Storage',
    '/models/bookshelf.glb',
    'https://images.pexels.com/photos/1090638/pexels-photo-1090638.jpeg?auto=compress&cs=tinysrgb&w=400',
    1.1,
    ARRAY[0.0, 0.0, 0.0]
  ),
  (
    gen_random_uuid(),
    'Minimalist Side Table',
    'Tables',
    '/models/side-table.glb',
    'https://images.pexels.com/photos/1866149/pexels-photo-1866149.jpeg?auto=compress&cs=tinysrgb&w=400',
    0.8,
    ARRAY[0.0, 0.0, 0.0]
  ),
  (
    gen_random_uuid(),
    'Executive Desk',
    'Tables',
    '/models/desk.glb',
    'https://images.pexels.com/photos/667838/pexels-photo-667838.jpeg?auto=compress&cs=tinysrgb&w=400',
    1.3,
    ARRAY[0.0, 0.0, 0.0]
  ),
  (
    gen_random_uuid(),
    'Floor Lamp',
    'Lighting',
    '/models/lamp.glb',
    'https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg?auto=compress&cs=tinysrgb&w=400',
    1.0,
    ARRAY[0.0, 0.0, 0.0]
  ),
  (
    gen_random_uuid(),
    'Storage Ottoman',
    'Storage',
    '/models/ottoman.glb',
    'https://images.pexels.com/photos/1148955/pexels-photo-1148955.jpeg?auto=compress&cs=tinysrgb&w=400',
    0.7,
    ARRAY[0.0, 0.0, 0.0]
  ),
  (
    gen_random_uuid(),
    'Bar Stool',
    'Seating',
    '/models/bar-stool.glb',
    'https://images.pexels.com/photos/1148955/pexels-photo-1148955.jpeg?auto=compress&cs=tinysrgb&w=400',
    0.9,
    ARRAY[0.0, 0.0, 0.0]
  );