/*
  # Create furniture catalog tables

  1. New Tables
    - `furniture_items`
      - `id` (uuid, primary key)
      - `name` (text)
      - `category` (text)
      - `model_url` (text) - URL to 3D model
      - `thumbnail_url` (text) - URL to preview image
      - `scale` (float) - Default scale for the model
      - `default_rotation` (float[3]) - Default rotation [x, y, z]
      - `created_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policy for public read access
*/

CREATE TABLE IF NOT EXISTS furniture_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL,
  model_url text NOT NULL,
  thumbnail_url text,
  scale float DEFAULT 1.0,
  default_rotation float[] DEFAULT ARRAY[0.0, 0.0, 0.0],
  created_at timestamptz DEFAULT now()
);

ALTER TABLE furniture_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read furniture items"
  ON furniture_items
  FOR SELECT
  TO public
  USING (true);