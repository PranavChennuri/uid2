import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Search, Filter, ChevronDown } from 'lucide-react';
import { useFurnitureStore } from '../../hooks/useFurnitureStore';

interface FurnitureCatalogProps {
  isOpen: boolean;
  onClose: () => void;
}

function FurnitureCatalog({ isOpen, onClose }: FurnitureCatalogProps) {
  const { catalog, addFurniture, selectCatalogItem, selectedCatalogItemId } = useFurnitureStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [categories, setCategories] = useState<string[]>([]);
  
  // Extract unique categories from catalog
  useEffect(() => {
    const uniqueCategories = Array.from(new Set(catalog.map(item => item.category)));
    setCategories(uniqueCategories);
  }, [catalog]);
  
  // Filter furniture based on search and category
  const filteredFurniture = catalog.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory ? item.category === selectedCategory : true;
    return matchesSearch && matchesCategory;
  });
  
  // Handle furniture selection
  const handleSelectFurniture = (furnitureId: string) => {
    selectCatalogItem(furnitureId);
    addFurniture(furnitureId);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ x: 300, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 300, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="furniture-catalog z-40"
        >
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-secondary-900">Furniture</h3>
            <button 
              onClick={onClose}
              className="p-1 rounded-full hover:bg-secondary-200 text-secondary-500"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          
          {/* Search */}
          <div className="relative mb-4">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-secondary-400" />
            </div>
            <input
              type="text"
              placeholder="Search furniture..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="form-input pl-10 py-2 text-sm"
            />
          </div>
          
          {/* Categories */}
          <div className="mb-4">
            <div className="flex items-center gap-2 mb-2">
              <Filter className="h-4 w-4 text-secondary-500" />
              <span className="text-sm font-medium text-secondary-700">Categories</span>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedCategory(null)}
                className={`px-3 py-1 text-xs rounded-full ${
                  selectedCategory === null
                    ? 'bg-primary-100 text-primary-700'
                    : 'bg-secondary-100 text-secondary-700 hover:bg-secondary-200'
                }`}
              >
                All
              </button>
              
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-3 py-1 text-xs rounded-full ${
                    selectedCategory === category
                      ? 'bg-primary-100 text-primary-700'
                      : 'bg-secondary-100 text-secondary-700 hover:bg-secondary-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          
          {/* Furniture List */}
          <div className="overflow-y-auto">
            {filteredFurniture.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-secondary-500">No furniture found</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {filteredFurniture.map(item => (
                  <motion.div
                    key={item.id}
                    whileHover={{ y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleSelectFurniture(item.id)}
                    className={`bg-white rounded-lg shadow-sm overflow-hidden cursor-pointer border transition-colors ${
                      selectedCatalogItemId === item.id 
                        ? 'border-primary-400 bg-primary-50' 
                        : 'border-secondary-200 hover:border-primary-400'
                    }`}
                  >
                    <div className="h-24 bg-secondary-100">
                      {item.thumbnail_url ? (
                        <img 
                          src={item.thumbnail_url} 
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-secondary-200">
                          <span className="text-xs text-secondary-500">No image</span>
                        </div>
                      )}
                    </div>
                    <div className="p-2">
                      <h4 className="text-sm font-medium text-secondary-900 truncate">{item.name}</h4>
                      <p className="text-xs text-secondary-500">{item.category}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
          
          {/* Instructions */}
          <div className="mt-4 p-3 bg-primary-50 rounded-lg border border-primary-200">
            <p className="text-xs text-primary-700">
              💡 Tap a furniture item to place it in your AR scene. Look for the placement indicator on the ground.
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default FurnitureCatalog;