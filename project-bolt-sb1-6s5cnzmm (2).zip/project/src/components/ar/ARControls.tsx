import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Plus, Minus, RotateCcw, Trash2, Menu, 
  Save, Move, Check, X, ArrowUpDown
} from 'lucide-react';
import { useFurnitureStore } from '../../hooks/useFurnitureStore';

interface ARControlsProps {
  onToggleCatalog: () => void;
  onSave: () => void;
}

function ARControls({ onToggleCatalog, onSave }: ARControlsProps) {
  const { 
    selectedItemId, 
    placedItems,
    removeFurniture,
    updateFurniture,
    clearScene
  } = useFurnitureStore();
  
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  
  // Get selected item
  const selectedItem = placedItems.find(item => item.id === selectedItemId);
  
  // Handle rotation
  const handleRotate = (amount: number) => {
    if (!selectedItem) return;
    
    const currentRotation = selectedItem.rotation;
    updateFurniture(selectedItem.id, {
      rotation: [currentRotation[0], currentRotation[1] + amount, currentRotation[2]]
    });
  };
  
  // Handle scale
  const handleScale = (delta: number) => {
    if (!selectedItem) return;
    
    const newScale = Math.max(0.1, selectedItem.scale + delta);
    updateFurniture(selectedItem.id, {
      scale: newScale
    });
  };
  
  // Handle height adjustment
  const handleHeightChange = (delta: number) => {
    if (!selectedItem) return;
    
    const currentPosition = selectedItem.position;
    updateFurniture(selectedItem.id, {
      position: [currentPosition[0], currentPosition[1] + delta, currentPosition[2]]
    });
  };
  
  // Handle delete
  const handleDelete = () => {
    if (!selectedItem) return;
    removeFurniture(selectedItem.id);
  };
  
  // Confirm clear scene
  const handleClearScene = () => {
    clearScene();
    setShowClearConfirm(false);
  };

  return (
    <div className="ar-controls">
      {/* Add furniture button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={onToggleCatalog}
        className="w-12 h-12 bg-primary-600 text-white rounded-full flex items-center justify-center shadow-lg"
      >
        <Menu className="h-6 w-6" />
      </motion.button>
      
      {/* Item-specific controls (only show when an item is selected) */}
      {selectedItem && (
        <div className="flex items-center gap-2">
          {/* Rotation controls */}
          <div className="bg-white/90 backdrop-blur-sm rounded-lg p-1 flex items-center shadow-soft">
            <button
              onClick={() => handleRotate(-Math.PI / 12)}
              className="p-2 hover:bg-secondary-100 rounded-md text-secondary-700"
              title="Rotate left"
            >
              <RotateCcw className="h-5 w-5" />
            </button>
            <button
              onClick={() => handleRotate(Math.PI / 12)}
              className="p-2 hover:bg-secondary-100 rounded-md text-secondary-700"
              title="Rotate right"
            >
              <RotateCcw className="h-5 w-5 transform scale-x-[-1]" />
            </button>
          </div>
          
          {/* Scale controls */}
          <div className="bg-white/90 backdrop-blur-sm rounded-lg p-1 flex items-center shadow-soft">
            <button
              onClick={() => handleScale(-0.1)}
              className="p-2 hover:bg-secondary-100 rounded-md text-secondary-700"
              title="Scale down"
            >
              <Minus className="h-5 w-5" />
            </button>
            <button
              onClick={() => handleScale(0.1)}
              className="p-2 hover:bg-secondary-100 rounded-md text-secondary-700"
              title="Scale up"
            >
              <Plus className="h-5 w-5" />
            </button>
          </div>
          
          {/* Height adjustment */}
          <div className="bg-white/90 backdrop-blur-sm rounded-lg p-1 flex items-center shadow-soft">
            <button
              onClick={() => handleHeightChange(-0.1)}
              className="p-2 hover:bg-secondary-100 rounded-md text-secondary-700"
              title="Lower"
            >
              <ArrowUpDown className="h-5 w-5 transform rotate-180" />
            </button>
            <button
              onClick={() => handleHeightChange(0.1)}
              className="p-2 hover:bg-secondary-100 rounded-md text-secondary-700"
              title="Raise"
            >
              <ArrowUpDown className="h-5 w-5" />
            </button>
          </div>
          
          {/* Delete button */}
          <button
            onClick={handleDelete}
            className="p-2 bg-error-100 hover:bg-error-200 rounded-md text-error-700 shadow-soft"
            title="Delete item"
          >
            <Trash2 className="h-5 w-5" />
          </button>
        </div>
      )}
      
      {/* General controls */}
      <div className="flex items-center gap-2">
        {/* Save button */}
        <button
          onClick={onSave}
          className="p-2 bg-accent-500 hover:bg-accent-600 rounded-md text-white shadow-soft"
          title="Save design"
        >
          <Save className="h-5 w-5" />
        </button>
        
        {/* Clear scene button with confirmation */}
        {showClearConfirm ? (
          <div className="bg-white/90 backdrop-blur-sm rounded-lg p-1 flex items-center shadow-soft">
            <span className="text-xs text-secondary-600 px-2">Clear all?</span>
            <button
              onClick={handleClearScene}
              className="p-2 hover:bg-success-100 rounded-md text-success-700"
              title="Confirm clear"
            >
              <Check className="h-5 w-5" />
            </button>
            <button
              onClick={() => setShowClearConfirm(false)}
              className="p-2 hover:bg-error-100 rounded-md text-error-700"
              title="Cancel"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => setShowClearConfirm(true)}
            className="p-2 bg-secondary-200 hover:bg-secondary-300 rounded-md text-secondary-700 shadow-soft"
            title="Clear scene"
          >
            <Trash2 className="h-5 w-5" />
          </button>
        )}
      </div>
    </div>
  );
}

export default ARControls;