import { useRef, useEffect, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF, Box } from '@react-three/drei';
import { Group, Mesh, BoxGeometry, MeshStandardMaterial } from 'three';
import { useFurnitureStore, PlacedFurniture } from '../../hooks/useFurnitureStore';

interface FurnitureModelProps {
  placedItem: PlacedFurniture;
  isSelected: boolean;
  onSelect?: () => void;
}

function FurnitureModel({ placedItem, isSelected, onSelect }: FurnitureModelProps) {
  const groupRef = useRef<Group>(null);
  const { catalog, updateFurniture } = useFurnitureStore();
  const [modelError, setModelError] = useState(false);
  
  // Find furniture data from catalog
  const furnitureData = catalog.find(item => item.id === placedItem.furnitureId);

  // Try to load 3D model, fallback to placeholder
  let scene;
  try {
    if (furnitureData?.model_url && !modelError) {
      const gltf = useGLTF(furnitureData.model_url);
      scene = gltf.scene;
    }
  } catch (error) {
    console.warn('Failed to load 3D model:', error);
    setModelError(true);
  }

  // Handle selection
  const handleClick = (e: any) => {
    e.stopPropagation();
    if (onSelect) {
      onSelect();
    }
  };

  // Apply transformations
  useEffect(() => {
    if (groupRef.current) {
      const [x, y, z] = placedItem.position;
      groupRef.current.position.set(x, y, z);
      
      const [rotX, rotY, rotZ] = placedItem.rotation;
      groupRef.current.rotation.set(rotX, rotY, rotZ);
      
      groupRef.current.scale.setScalar(placedItem.scale);
    }
  }, [placedItem]);

  // Selection animation
  useFrame((state) => {
    if (groupRef.current && isSelected) {
      const time = state.clock.elapsedTime;
      const baseY = placedItem.position[1];
      groupRef.current.position.y = baseY + Math.sin(time * 4) * 0.02;
    }
  });

  if (!furnitureData) {
    return null;
  }

  return (
    <group 
      ref={groupRef}
      onClick={handleClick}
      onPointerDown={handleClick}
    >
      {/* 3D Model or Placeholder */}
      {scene && !modelError ? (
        <primitive object={scene.clone()} />
      ) : (
        // Fallback placeholder box
        <Box args={[0.5, 0.5, 0.5]} castShadow receiveShadow>
          <meshStandardMaterial 
            color={isSelected ? "#0D9488" : "#94a3b8"} 
            roughness={0.7}
            metalness={0.1}
          />
        </Box>
      )}
      
      {/* Selection indicator */}
      {isSelected && (
        <mesh position={[0, -0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.6, 0.65, 32]} />
          <meshBasicMaterial 
            color="#0D9488" 
            transparent 
            opacity={0.8}
          />
        </mesh>
      )}
      
      {/* Shadow catcher for AR */}
      <mesh 
        position={[0, -0.001, 0]} 
        rotation={[-Math.PI / 2, 0, 0]}
        receiveShadow
      >
        <circleGeometry args={[0.8, 32]} />
        <meshStandardMaterial 
          color="#000000"
          transparent
          opacity={0.2}
          roughness={1}
          metalness={0}
        />
      </mesh>
    </group>
  );
}

export default FurnitureModel;