import { useRef, useState, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { ARButton, XR, Controllers } from '@react-three/xr';
import { Environment } from '@react-three/drei';
import { useFurnitureStore } from '../../hooks/useFurnitureStore';
import FurnitureCatalog from './FurnitureCatalog';
import FurnitureModel from './FurnitureModel';
import ARControls from './ARControls';
import ARPlacementIndicator from './ARPlacementIndicator';
import SaveDesignModal from './SaveDesignModal';

function ARScene() {
  const { 
    placedItems, 
    selectedItemId, 
    selectFurniture,
    fetchCatalog,
    isLoading,
    error
  } = useFurnitureStore();
  
  const [showCatalog, setShowCatalog] = useState(false);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [arSupported, setArSupported] = useState<boolean | null>(null);
  const [isPresenting, setIsPresenting] = useState(false);
  
  useEffect(() => {
    // Check AR support
    if ('xr' in navigator && navigator.xr) {
      navigator.xr.isSessionSupported('immersive-ar')
        .then(supported => {
          console.log('AR supported:', supported);
          setArSupported(supported);
        })
        .catch(err => {
          console.error('Error checking AR support:', err);
          setArSupported(false);
        });
    } else {
      console.log('WebXR not available');
      setArSupported(false);
    }
    
    // Fetch furniture catalog
    fetchCatalog();
  }, [fetchCatalog]);

  const toggleCatalog = () => setShowCatalog(!showCatalog);
  
  const handleBackgroundClick = () => {
    if (selectedItemId) {
      selectFurniture(null);
    }
  };

  const handleSessionStart = () => {
    console.log('AR session started');
    setIsPresenting(true);
  };

  const handleSessionEnd = () => {
    console.log('AR session ended');
    setIsPresenting(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-secondary-50">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary-600 mb-4"></div>
          <p className="text-secondary-600">Loading AR Experience...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-screen bg-secondary-50">
        <div className="text-center max-w-md p-6 bg-white rounded-lg shadow-soft">
          <div className="text-error-600 text-4xl mb-4">⚠️</div>
          <h2 className="text-xl font-semibold text-secondary-900 mb-2">Error Loading AR</h2>
          <p className="text-secondary-600 mb-4">{error}</p>
          <button 
            onClick={() => fetchCatalog()}
            className="btn btn-primary"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  if (arSupported === false) {
    return (
      <div className="flex items-center justify-center h-screen bg-secondary-50">
        <div className="text-center max-w-md p-6 bg-white rounded-lg shadow-soft">
          <div className="text-warning-500 text-4xl mb-4">📱</div>
          <h2 className="text-xl font-semibold text-secondary-900 mb-2">AR Not Available</h2>
          <p className="text-secondary-600 mb-4">
            WebXR AR is not supported on this device/browser. For the best AR experience, please use:
          </p>
          <ul className="text-left text-secondary-600 mb-4 space-y-1">
            <li>• Chrome on Android with ARCore</li>
            <li>• Safari on iOS with ARKit</li>
            <li>• Chrome on desktop with WebXR flags enabled</li>
          </ul>
          <div className="space-y-2">
            <button 
              onClick={() => setArSupported(true)}
              className="btn btn-primary w-full"
            >
              Try Anyway (Demo Mode)
            </button>
            <a 
              href="https://immersiveweb.dev/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="btn btn-secondary w-full"
            >
              Learn About WebXR
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen relative bg-black">
      <Canvas 
        shadows 
        camera={{ position: [0, 1.6, 3], fov: 75 }}
        gl={{ alpha: false }}
      >
        <XR 
          onSessionStart={handleSessionStart}
          onSessionEnd={handleSessionEnd}
        >
          <Environment preset="sunset" />
          <Controllers />
          
          {/* Lighting */}
          <ambientLight intensity={0.6} />
          <directionalLight 
            position={[10, 10, 5]} 
            intensity={1} 
            castShadow 
            shadow-mapSize={[2048, 2048]}
            shadow-camera-far={50}
            shadow-camera-left={-10}
            shadow-camera-right={10}
            shadow-camera-top={10}
            shadow-camera-bottom={-10}
          />
          
          {/* AR Placement Indicator */}
          <ARPlacementIndicator />
          
          {/* Placed Furniture Items */}
          {placedItems.map(item => (
            <FurnitureModel 
              key={item.id}
              placedItem={item}
              isSelected={item.id === selectedItemId}
              onSelect={() => selectFurniture(item.id)}
            />
          ))}
          
          {/* Ground plane for non-AR mode */}
          {!isPresenting && (
            <mesh 
              rotation={[-Math.PI / 2, 0, 0]} 
              position={[0, -0.5, 0]}
              receiveShadow
              onClick={handleBackgroundClick}
            >
              <planeGeometry args={[20, 20]} />
              <meshStandardMaterial color="#f0f0f0" />
            </mesh>
          )}
        </XR>
      </Canvas>
      
      {/* AR Button */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-50">
        <ARButton 
          className="px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-lg shadow-lg font-medium transition-colors"
          sessionInit={{ 
            requiredFeatures: ['hit-test'],
            optionalFeatures: ['dom-overlay'],
            domOverlay: { root: document.body }
          }}
        >
          {isPresenting ? 'Exit AR' : 'Start AR'}
        </ARButton>
      </div>
      
      {/* Instructions */}
      {!isPresenting && (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 z-40 bg-white/90 backdrop-blur-sm rounded-lg p-4 max-w-sm text-center">
          <p className="text-sm text-secondary-700">
            Click "Start AR" to begin placing furniture in your real environment
          </p>
        </div>
      )}
      
      {/* Furniture Catalog Panel */}
      <FurnitureCatalog 
        isOpen={showCatalog} 
        onClose={() => setShowCatalog(false)} 
      />
      
      {/* AR Controls */}
      <ARControls 
        onToggleCatalog={toggleCatalog} 
        onSave={() => setShowSaveModal(true)}
      />
      
      {/* Save Design Modal */}
      {showSaveModal && (
        <SaveDesignModal onClose={() => setShowSaveModal(false)} />
      )}
    </div>
  );
}

export default ARScene;