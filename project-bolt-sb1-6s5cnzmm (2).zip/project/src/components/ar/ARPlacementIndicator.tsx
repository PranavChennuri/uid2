import { useRef, useState, useEffect } from 'react';
import { useThree, useFrame } from '@react-three/fiber';
import { useXR } from '@react-three/xr';
import { useFurnitureStore } from '../../hooks/useFurnitureStore';
import * as THREE from 'three';

function ARPlacementIndicator() {
  const { isPresenting, hitTestSource, hitTestSourceRequested } = useXR();
  const reticleRef = useRef<THREE.Group>(null);
  const { gl, scene } = useThree();
  const [reticleVisible, setReticleVisible] = useState(false);
  const { addFurniture, catalog, selectedCatalogItemId } = useFurnitureStore();
  
  // Create hit test source when AR session starts
  useEffect(() => {
    if (!isPresenting) {
      setReticleVisible(false);
      return;
    }

    const session = gl.xr.getSession();
    if (!session) return;

    session.requestReferenceSpace('viewer').then((referenceSpace) => {
      session.requestHitTestSource?.({ space: referenceSpace })?.then((source) => {
        hitTestSource.current = source;
        hitTestSourceRequested.current = true;
      });
    });

    return () => {
      if (hitTestSource.current) {
        hitTestSource.current.cancel();
        hitTestSource.current = null;
        hitTestSourceRequested.current = false;
      }
    };
  }, [isPresenting, gl.xr, hitTestSource, hitTestSourceRequested]);

  // Animation for the indicator
  useFrame((state, delta) => {
    if (reticleRef.current && reticleVisible) {
      // Gentle pulse animation
      const scale = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.1;
      reticleRef.current.scale.setScalar(scale);
      
      // Subtle rotation
      reticleRef.current.rotation.y += delta * 0.5;
    }
  });

  // Hit test frame loop
  useFrame((state, delta, xrFrame) => {
    if (!isPresenting || !xrFrame || !hitTestSourceRequested.current || !hitTestSource.current) {
      setReticleVisible(false);
      return;
    }

    const referenceSpace = gl.xr.getReferenceSpace();
    if (!referenceSpace) return;

    const hitTestResults = xrFrame.getHitTestResults(hitTestSource.current);
    
    if (hitTestResults.length > 0) {
      const hit = hitTestResults[0];
      const pose = hit.getPose(referenceSpace);
      
      if (pose && reticleRef.current) {
        const matrix = new THREE.Matrix4().fromArray(pose.transform.matrix);
        reticleRef.current.matrix.copy(matrix);
        reticleRef.current.matrix.decompose(
          reticleRef.current.position,
          reticleRef.current.quaternion,
          reticleRef.current.scale
        );
        setReticleVisible(true);
      }
    } else {
      setReticleVisible(false);
    }
  });

  // Handle tap to place furniture
  const handleSelect = () => {
    if (!reticleVisible || !reticleRef.current) return;
    
    // Use the first furniture item if none is selected
    const itemToPlace = selectedCatalogItemId || (catalog.length > 0 ? catalog[0].id : null);
    
    if (itemToPlace) {
      // Get position from reticle
      const position = reticleRef.current.position;
      addFurniture(itemToPlace, [position.x, position.y, position.z]);
    }
  };

  if (!isPresenting) return null;

  return (
    <group 
      ref={reticleRef} 
      visible={reticleVisible}
      onClick={handleSelect}
      onPointerDown={handleSelect}
    >
      {/* Outer ring */}
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.14, 0.16, 32]} />
        <meshBasicMaterial 
          color="#0D9488" 
          transparent 
          opacity={0.8}
          side={THREE.DoubleSide}
        />
      </mesh>
      
      {/* Inner circle */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.001, 0]}>
        <circleGeometry args={[0.08, 32]} />
        <meshBasicMaterial 
          color="#0D9488" 
          transparent 
          opacity={0.4}
          side={THREE.DoubleSide}
        />
      </mesh>
      
      {/* Center dot */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.002, 0]}>
        <circleGeometry args={[0.02, 16]} />
        <meshBasicMaterial 
          color="#F59E0B"
          side={THREE.DoubleSide}
        />
      </mesh>
      
      {/* Crosshair lines */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.003, 0]}>
        <planeGeometry args={[0.3, 0.01]} />
        <meshBasicMaterial 
          color="#0D9488" 
          transparent 
          opacity={0.6}
          side={THREE.DoubleSide}
        />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, Math.PI / 2]} position={[0, 0.003, 0]}>
        <planeGeometry args={[0.3, 0.01]} />
        <meshBasicMaterial 
          color="#0D9488" 
          transparent 
          opacity={0.6}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}

export default ARPlacementIndicator;