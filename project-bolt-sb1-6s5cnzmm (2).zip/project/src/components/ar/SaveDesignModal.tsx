import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Camera, Upload, Save } from 'lucide-react';
import { useFurnitureStore } from '../../hooks/useFurnitureStore';

interface SaveDesignModalProps {
  onClose: () => void;
}

function SaveDesignModal({ onClose }: SaveDesignModalProps) {
  const [designName, setDesignName] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const { saveDesign } = useFurnitureStore();
  
  const handleSave = async () => {
    if (!designName.trim()) {
      setError('Please enter a name for your design');
      return;
    }
    
    try {
      setSaving(true);
      setError(null);
      
      // For a real implementation, we would capture a screenshot here
      // and upload it as the thumbnail
      const thumbnailUrl = 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1';
      
      const result = await saveDesign(designName, thumbnailUrl);
      
      if (!result.success) {
        throw new Error(result.error || 'Failed to save design');
      }
      
      setSuccess(true);
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setSaving(false);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-secondary-900/70 backdrop-blur-sm z-50 flex items-center justify-center"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          transition={{ type: 'spring', damping: 25 }}
          className="bg-white rounded-lg shadow-xl max-w-md w-full mx-4 overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="p-4 bg-primary-600 text-white flex justify-between items-center">
            <h3 className="text-lg font-semibold">Save Your Design</h3>
            <button 
              onClick={onClose}
              className="p-1 rounded-full hover:bg-primary-500 text-white/90 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          
          <div className="p-6">
            {success ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-8"
              >
                <div className="mx-auto w-16 h-16 bg-success-100 rounded-full flex items-center justify-center mb-4">
                  <Save className="h-8 w-8 text-success-600" />
                </div>
                <h4 className="text-xl font-semibold text-secondary-900 mb-2">Design Saved!</h4>
                <p className="text-secondary-600">
                  Your design has been saved successfully.
                </p>
              </motion.div>
            ) : (
              <>
                <div className="mb-6">
                  <label htmlFor="designName" className="form-label">
                    Design Name
                  </label>
                  <input
                    id="designName"
                    type="text"
                    value={designName}
                    onChange={(e) => setDesignName(e.target.value)}
                    placeholder="My Living Room"
                    className="form-input"
                    autoFocus
                  />
                </div>
                
                <div className="mb-6">
                  <p className="form-label mb-2">Preview Image</p>
                  <div className="bg-secondary-100 rounded-lg h-48 flex items-center justify-center border border-secondary-200">
                    <div className="text-center">
                      <div className="flex justify-center mb-2">
                        <Camera className="h-8 w-8 text-secondary-400" />
                      </div>
                      <p className="text-secondary-600 text-sm mb-3">
                        A screenshot of your design will be captured
                      </p>
                      <button className="btn btn-secondary text-sm flex items-center mx-auto">
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Custom Image
                      </button>
                    </div>
                  </div>
                </div>
                
                {error && (
                  <div className="mb-4 p-3 rounded-md bg-error-50 border border-error-200 text-error-700 text-sm">
                    {error}
                  </div>
                )}
                
                <div className="flex justify-end gap-3">
                  <button 
                    onClick={onClose}
                    className="btn btn-secondary"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleSave}
                    disabled={saving}
                    className="btn btn-primary flex items-center"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {saving ? 'Saving...' : 'Save Design'}
                  </button>
                </div>
              </>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

export default SaveDesignModal;