import { motion } from 'framer-motion';
import { Sofa } from 'lucide-react';

function LoadingScreen() {
  return (
    <div className="fixed inset-0 bg-white flex flex-col items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col items-center"
      >
        <Sofa className="h-16 w-16 text-primary-600" />
        <h1 className="text-2xl font-bold text-primary-700 mt-4">ARniture</h1>
      </motion.div>
      
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: '60%' }}
        transition={{ duration: 1.5, repeat: Infinity }}
        className="h-1 bg-primary-500 rounded-full mt-8"
        style={{ maxWidth: '250px' }}
      />
      
      <p className="mt-4 text-secondary-500">Loading your AR experience...</p>
    </div>
  );
}

export default LoadingScreen;