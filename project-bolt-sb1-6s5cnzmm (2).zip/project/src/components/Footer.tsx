import { Link } from 'react-router-dom';
import { Sofa, Github, Twitter, Instagram } from 'lucide-react';

function Footer() {
  return (
    <footer className="bg-secondary-900 text-white">
      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center gap-2">
              <Sofa className="h-8 w-8 text-primary-400" />
              <span className="font-bold text-xl text-white">ARniture</span>
            </Link>
            <p className="mt-2 text-secondary-300 text-sm">
              Experience furniture in your space before you buy with our AR technology.
            </p>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-secondary-200 tracking-wider uppercase">Company</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/" className="text-secondary-300 hover:text-white">Home</Link>
              </li>
              <li>
                <Link to="/about" className="text-secondary-300 hover:text-white">About</Link>
              </li>
              <li>
                <Link to="/contact" className="text-secondary-300 hover:text-white">Contact</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-secondary-200 tracking-wider uppercase">Services</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/ar" className="text-secondary-300 hover:text-white">AR Experience</Link>
              </li>
              <li>
                <Link to="/catalog" className="text-secondary-300 hover:text-white">Furniture Catalog</Link>
              </li>
              <li>
                <Link to="/saved-designs" className="text-secondary-300 hover:text-white">Saved Designs</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-secondary-200 tracking-wider uppercase">Connect</h3>
            <div className="mt-4 flex space-x-6">
              <a href="#" className="text-secondary-300 hover:text-white">
                <Github className="h-6 w-6" />
              </a>
              <a href="#" className="text-secondary-300 hover:text-white">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-secondary-300 hover:text-white">
                <Instagram className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-12 border-t border-secondary-700 pt-8">
          <p className="text-secondary-400 text-sm text-center">
            &copy; {new Date().getFullYear()} ARniture. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;