import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Menu, X, Sofa, UserCircle, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const toggleMenu = () => setIsOpen(!isOpen);
  const closeMenu = () => setIsOpen(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
    closeMenu();
  };

  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2">
              <Sofa className="h-8 w-8 text-primary-600" />
              <span className="font-bold text-xl text-primary-700">ARniture</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden sm:flex sm:items-center sm:space-x-4">
            <NavLink 
              to="/" 
              className={({ isActive }) => 
                isActive ? 'nav-link nav-link-active' : 'nav-link'
              }
            >
              Home
            </NavLink>
            
            {user ? (
              <>
                <NavLink 
                  to="/ar" 
                  className={({ isActive }) => 
                    isActive ? 'nav-link nav-link-active' : 'nav-link'
                  }
                >
                  AR Experience
                </NavLink>
                <NavLink 
                  to="/saved-designs" 
                  className={({ isActive }) => 
                    isActive ? 'nav-link nav-link-active' : 'nav-link'
                  }
                >
                  Saved Designs
                </NavLink>
                <NavLink 
                  to="/profile" 
                  className={({ isActive }) => 
                    isActive ? 'nav-link nav-link-active' : 'nav-link'
                  }
                >
                  <UserCircle className="h-5 w-5 inline mr-1" />
                  Profile
                </NavLink>
                <button 
                  onClick={handleSignOut}
                  className="nav-link text-error-600 hover:text-error-700 flex items-center"
                >
                  <LogOut className="h-5 w-5 mr-1" />
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <NavLink 
                  to="/login" 
                  className={({ isActive }) => 
                    isActive ? 'nav-link nav-link-active' : 'nav-link'
                  }
                >
                  Log In
                </NavLink>
                <NavLink 
                  to="/register" 
                  className="btn btn-primary"
                >
                  Sign Up
                </NavLink>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center sm:hidden">
            <button
              onClick={toggleMenu}
              className="p-2 rounded-md text-secondary-500 hover:text-secondary-900 hover:bg-secondary-100 focus:outline-none"
            >
              {isOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="sm:hidden bg-white border-b border-secondary-200"
          >
            <div className="flex flex-col pt-2 pb-4 space-y-1 px-4">
              <NavLink 
                to="/"
                onClick={closeMenu}
                className={({ isActive }) => 
                  isActive ? 'nav-link nav-link-active' : 'nav-link'
                }
              >
                Home
              </NavLink>
              
              {user ? (
                <>
                  <NavLink 
                    to="/ar"
                    onClick={closeMenu} 
                    className={({ isActive }) => 
                      isActive ? 'nav-link nav-link-active' : 'nav-link'
                    }
                  >
                    AR Experience
                  </NavLink>
                  <NavLink 
                    to="/saved-designs"
                    onClick={closeMenu} 
                    className={({ isActive }) => 
                      isActive ? 'nav-link nav-link-active' : 'nav-link'
                    }
                  >
                    Saved Designs
                  </NavLink>
                  <NavLink 
                    to="/profile"
                    onClick={closeMenu} 
                    className={({ isActive }) => 
                      isActive ? 'nav-link nav-link-active' : 'nav-link'
                    }
                  >
                    <UserCircle className="h-5 w-5 inline mr-1" />
                    Profile
                  </NavLink>
                  <button 
                    onClick={handleSignOut}
                    className="nav-link text-error-600 hover:text-error-700 flex items-center"
                  >
                    <LogOut className="h-5 w-5 mr-1" />
                    Sign Out
                  </button>
                </>
              ) : (
                <>
                  <NavLink 
                    to="/login"
                    onClick={closeMenu} 
                    className={({ isActive }) => 
                      isActive ? 'nav-link nav-link-active' : 'nav-link'
                    }
                  >
                    Log In
                  </NavLink>
                  <NavLink 
                    to="/register"
                    onClick={closeMenu}
                    className="btn btn-primary block text-center mt-2"
                  >
                    Sign Up
                  </NavLink>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

export default Navbar;