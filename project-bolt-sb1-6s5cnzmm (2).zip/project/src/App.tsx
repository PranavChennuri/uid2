import { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';

// Pages
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import ARScene from './components/ar/ARScene';
import Profile from './pages/Profile';
import SavedDesigns from './pages/SavedDesigns';

// Components
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import LoadingScreen from './components/common/LoadingScreen';

function App() {
  const { user, loading } = useAuth();

  useEffect(() => {
    // Check for WebXR support
    if ('xr' in navigator) {
      navigator.xr?.isSessionSupported('immersive-ar')
        .then((supported) => {
          if (!supported) {
            console.log('WebXR AR not supported in this browser');
          }
        })
        .catch(err => {
          console.error('Error checking AR support:', err);
        });
    } else {
      console.log('WebXR not supported in this browser');
    }
  }, []);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="login" element={!user ? <Login /> : <Navigate to="/profile" />} />
        <Route path="register" element={!user ? <Register /> : <Navigate to="/profile" />} />
        
        {/* Protected Routes */}
        <Route path="ar" element={
          <ProtectedRoute>
            <ARScene />
          </ProtectedRoute>
        } />
        <Route path="profile" element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        } />
        <Route path="saved-designs" element={
          <ProtectedRoute>
            <SavedDesigns />
          </ProtectedRoute>
        } />
        
        {/* Fallback route */}
        <Route path="*" element={<Navigate to="/\" replace />} />
      </Route>
    </Routes>
  );
}

export default App;