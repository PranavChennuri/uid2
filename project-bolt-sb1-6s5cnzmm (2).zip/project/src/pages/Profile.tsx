import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { motion } from 'framer-motion';
import { Edit, Save, User } from 'lucide-react';

interface ProfileData {
  username: string;
  full_name: string;
  avatar_url: string | null;
}

function Profile() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const [profileData, setProfileData] = useState<ProfileData>({
    username: '',
    full_name: '',
    avatar_url: null,
  });
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    async function loadProfile() {
      try {
        setLoading(true);
        
        if (!user) return;

        const { data, error } = await supabase
          .from('profiles')
          .select('username, full_name, avatar_url')
          .eq('id', user.id)
          .single();

        if (error) {
          console.error('Error fetching profile:', error);
          return;
        }

        if (data) {
          setProfileData({
            username: data.username || '',
            full_name: data.full_name || '',
            avatar_url: data.avatar_url,
          });
        }
      } catch (error) {
        console.error('Error loading profile:', error);
      } finally {
        setLoading(false);
      }
    }

    loadProfile();
  }, [user]);

  const updateProfile = async () => {
    try {
      setUpdating(true);
      
      if (!user) return;

      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          username: profileData.username,
          full_name: profileData.full_name,
          avatar_url: profileData.avatar_url,
          updated_at: new Date().toISOString(),
        });

      if (error) {
        console.error('Error updating profile:', error);
        return;
      }

      setIsEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setUpdating(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] py-12 px-4 sm:px-6 lg:px-8 bg-secondary-50">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white rounded-lg shadow-soft overflow-hidden"
        >
          <div className="h-32 bg-gradient-to-r from-primary-700 to-primary-500"></div>
          
          <div className="relative px-6 pb-6">
            <div className="flex flex-col sm:flex-row gap-6 -mt-16 sm:-mt-12">
              <div className="flex-shrink-0">
                <div className="h-32 w-32 rounded-full bg-white p-2 shadow-md">
                  {profileData.avatar_url ? (
                    <img 
                      src={profileData.avatar_url} 
                      alt="Profile"
                      className="h-full w-full rounded-full object-cover"
                    />
                  ) : (
                    <div className="h-full w-full rounded-full bg-primary-100 flex items-center justify-center">
                      <User className="h-16 w-16 text-primary-500" />
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex flex-col justify-end mt-4 sm:mt-0">
                <div className="flex items-center gap-4">
                  <h1 className="text-2xl font-bold text-secondary-900">
                    {loading ? 'Loading...' : profileData.full_name || 'Add your name'}
                  </h1>
                  <button 
                    onClick={() => setIsEditing(!isEditing)}
                    className="p-2 rounded-full bg-secondary-100 hover:bg-secondary-200 text-secondary-700"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                </div>
                <p className="text-secondary-500">@{profileData.username || user?.email?.split('@')[0] || 'username'}</p>
                <p className="text-secondary-600 mt-2">{user?.email}</p>
              </div>
            </div>

            {isEditing && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="mt-8"
              >
                <h2 className="text-lg font-semibold text-secondary-900 mb-4">Edit Profile</h2>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="full_name" className="form-label">
                      Full Name
                    </label>
                    <input
                      id="full_name"
                      type="text"
                      value={profileData.full_name}
                      onChange={(e) => setProfileData({ ...profileData, full_name: e.target.value })}
                      className="form-input"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="username" className="form-label">
                      Username
                    </label>
                    <input
                      id="username"
                      type="text"
                      value={profileData.username}
                      onChange={(e) => setProfileData({ ...profileData, username: e.target.value })}
                      className="form-input"
                    />
                  </div>
                  
                  <div className="pt-4">
                    <button
                      onClick={updateProfile}
                      disabled={updating}
                      className="btn btn-primary flex items-center"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {updating ? 'Saving...' : 'Save Changes'}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            <div className="mt-8 border-t border-secondary-200 pt-6">
              <h2 className="text-lg font-semibold text-secondary-900 mb-4">Your Stats</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="bg-secondary-50 rounded-lg p-4 text-center">
                  <p className="text-2xl font-bold text-primary-600">0</p>
                  <p className="text-secondary-600">Saved Designs</p>
                </div>
                <div className="bg-secondary-50 rounded-lg p-4 text-center">
                  <p className="text-2xl font-bold text-primary-600">0</p>
                  <p className="text-secondary-600">Furniture Placed</p>
                </div>
                <div className="bg-secondary-50 rounded-lg p-4 text-center">
                  <p className="text-2xl font-bold text-primary-600">0</p>
                  <p className="text-secondary-600">AR Sessions</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

export default Profile;