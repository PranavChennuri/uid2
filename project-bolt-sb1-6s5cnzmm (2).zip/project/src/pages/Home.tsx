import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Smartphone, Save, Layers } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

function Home() {
  const { user } = useAuth();
  
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary-900 to-primary-700 text-white">
        <div className="max-w-7xl mx-auto px-4 py-24 sm:px-6 lg:px-8 flex flex-col lg:flex-row items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="lg:w-1/2 lg:pr-12 mb-10 lg:mb-0"
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
              Design Your Space in Augmented Reality
            </h1>
            <p className="text-lg sm:text-xl mb-8 text-primary-100">
              Place virtual furniture in your real environment before making a purchase decision. Experience how new pieces fit and look in your space.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to={user ? "/ar" : "/register"} className="btn bg-accent-500 hover:bg-accent-600 text-white px-8 py-3 rounded-lg font-medium flex items-center">
                {user ? "Start AR Experience" : "Sign Up & Get Started"}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link to="/about" className="btn bg-white/10 hover:bg-white/20 text-white border border-white/30 px-8 py-3 rounded-lg font-medium">
                Learn More
              </Link>
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="lg:w-1/2"
          >
            <div className="relative h-[400px] lg:h-[500px] rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="AR Furniture Preview" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary-900/60 to-transparent" />
              <div className="absolute bottom-8 left-8 right-8 bg-white/10 backdrop-blur-sm p-4 rounded-lg border border-white/20">
                <div className="flex items-center gap-3">
                  <div className="bg-accent-500 rounded-full p-2">
                    <Smartphone className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-medium">AR Mode Active</p>
                    <p className="text-white/80 text-sm">Mid-century sofa in view</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-secondary-900 mb-4">How ARniture Works</h2>
            <p className="text-lg text-secondary-600 max-w-2xl mx-auto">
              Our augmented reality technology allows you to visualize furniture in your space before making a purchase decision.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <motion.div 
              whileHover={{ y: -8 }}
              className="flex flex-col items-center text-center"
            >
              <div className="bg-primary-100 p-4 rounded-2xl mb-5">
                <Smartphone className="h-12 w-12 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-secondary-900">Scan Your Space</h3>
              <p className="text-secondary-600">
                Use your device's camera to scan your room and create a virtual canvas for furniture placement.
              </p>
            </motion.div>

            <motion.div 
              whileHover={{ y: -8 }}
              className="flex flex-col items-center text-center"
            >
              <div className="bg-primary-100 p-4 rounded-2xl mb-5">
                <Layers className="h-12 w-12 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-secondary-900">Browse & Place</h3>
              <p className="text-secondary-600">
                Select from our extensive furniture catalog and place items in your space with drag-and-drop simplicity.
              </p>
            </motion.div>

            <motion.div 
              whileHover={{ y: -8 }}
              className="flex flex-col items-center text-center"
            >
              <div className="bg-primary-100 p-4 rounded-2xl mb-5">
                <Save className="h-12 w-12 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-secondary-900">Save & Share</h3>
              <p className="text-secondary-600">
                Save your designs to revisit later or share with friends and family to get their opinion.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-secondary-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-primary-700 to-primary-600 rounded-2xl shadow-xl overflow-hidden">
            <div className="flex flex-col lg:flex-row">
              <div className="p-8 sm:p-12 lg:w-1/2">
                <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
                  Ready to transform your space?
                </h2>
                <p className="text-primary-100 text-lg mb-8">
                  Join thousands of users who have designed their perfect space using our AR technology.
                </p>
                <Link 
                  to={user ? "/ar" : "/register"} 
                  className="inline-block bg-white text-primary-700 hover:bg-primary-50 px-8 py-3 rounded-lg font-medium"
                >
                  {user ? "Launch AR Experience" : "Get Started for Free"}
                </Link>
              </div>
              <div className="lg:w-1/2 relative min-h-[300px]">
                <img 
                  src="https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                  alt="Modern living room" 
                  className="absolute inset-0 h-full w-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;