import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { motion } from 'framer-motion';
import { Eye, Download, Trash2, Plus, Search } from 'lucide-react';

interface SavedDesign {
  id: string;
  created_at: string;
  name: string;
  thumbnail_url: string;
  user_id: string;
}

function SavedDesigns() {
  const { user } = useAuth();
  const [designs, setDesigns] = useState<SavedDesign[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    async function fetchDesigns() {
      try {
        setLoading(true);
        
        if (!user) return;

        const { data, error } = await supabase
          .from('saved_designs')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });

        if (error) {
          console.error('Error fetching designs:', error);
          return;
        }

        setDesigns(data || []);
      } catch (error) {
        console.error('Error fetching designs:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchDesigns();
  }, [user]);

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('saved_designs')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting design:', error);
        return;
      }

      setDesigns(designs.filter(design => design.id !== id));
    } catch (error) {
      console.error('Error deleting design:', error);
    }
  };

  const filteredDesigns = designs.filter(design => 
    design.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] py-12 px-4 sm:px-6 lg:px-8 bg-secondary-50">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <h1 className="text-3xl font-bold text-secondary-900 mb-4 sm:mb-0">Saved Designs</h1>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-secondary-400" />
              </div>
              <input
                type="text"
                placeholder="Search designs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="form-input pl-10 w-full sm:w-64"
              />
            </div>
            
            <Link to="/ar" className="btn btn-primary flex items-center justify-center">
              <Plus className="h-5 w-5 mr-2" />
              New Design
            </Link>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="loader">Loading...</div>
          </div>
        ) : designs.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-lg shadow-soft">
            <h3 className="text-xl font-medium text-secondary-900 mb-2">No saved designs yet</h3>
            <p className="text-secondary-600 mb-6">Start by creating your first AR design</p>
            <Link to="/ar" className="btn btn-primary inline-flex items-center">
              <Plus className="h-5 w-5 mr-2" />
              Create New Design
            </Link>
          </div>
        ) : (
          <motion.div 
            variants={container}
            initial="hidden"
            animate="show"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredDesigns.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <p className="text-secondary-600">No designs matching "{searchTerm}"</p>
              </div>
            ) : (
              filteredDesigns.map(design => (
                <motion.div 
                  key={design.id}
                  variants={item}
                  className="bg-white rounded-lg shadow-soft overflow-hidden"
                >
                  <div className="relative h-48 bg-secondary-100">
                    {design.thumbnail_url ? (
                      <img 
                        src={design.thumbnail_url} 
                        alt={design.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-primary-50">
                        <p className="text-primary-500">No preview available</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="p-4">
                    <h3 className="text-lg font-semibold text-secondary-900 mb-1">{design.name}</h3>
                    <p className="text-sm text-secondary-500 mb-4">
                      {new Date(design.created_at).toLocaleDateString()}
                    </p>
                    
                    <div className="flex justify-between">
                      <div className="flex gap-2">
                        <button 
                          className="p-2 rounded-md bg-secondary-100 hover:bg-secondary-200 text-secondary-700"
                          title="View design"
                        >
                          <Eye className="h-5 w-5" />
                        </button>
                        <button 
                          className="p-2 rounded-md bg-secondary-100 hover:bg-secondary-200 text-secondary-700"
                          title="Download"
                        >
                          <Download className="h-5 w-5" />
                        </button>
                      </div>
                      
                      <button 
                        onClick={() => handleDelete(design.id)}
                        className="p-2 rounded-md bg-error-100 hover:bg-error-200 text-error-700"
                        title="Delete design"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
}

export default SavedDesigns;