import { create } from 'zustand';
import { supabase } from '../lib/supabase';

export interface FurnitureItem {
  id: string;
  name: string;
  category: string;
  model_url: string;
  thumbnail_url: string;
  scale: number;
  default_rotation: [number, number, number];
}

export interface PlacedFurniture {
  id: string;
  furnitureId: string;
  position: [number, number, number];
  rotation: [number, number, number];
  scale: number;
}

interface FurnitureState {
  catalog: FurnitureItem[];
  placedItems: PlacedFurniture[];
  selectedItemId: string | null;
  selectedCatalogItemId: string | null;
  isLoading: boolean;
  error: string | null;

  // Actions
  fetchCatalog: () => Promise<void>;
  addFurniture: (furnitureId: string, position?: [number, number, number]) => void;
  removeFurniture: (placedId: string) => void;
  updateFurniture: (placedId: string, updates: Partial<PlacedFurniture>) => void;
  selectFurniture: (placedId: string | null) => void;
  selectCatalogItem: (catalogId: string | null) => void;
  clearScene: () => void;
  saveDesign: (name: string, thumbnailUrl?: string) => Promise<{ success: boolean; error?: string }>;
  loadDesign: (designId: string) => Promise<{ success: boolean; error?: string }>;
}

export const useFurnitureStore = create<FurnitureState>((set, get) => ({
  catalog: [],
  placedItems: [],
  selectedItemId: null,
  selectedCatalogItemId: null,
  isLoading: false,
  error: null,

  fetchCatalog: async () => {
    try {
      set({ isLoading: true, error: null });
      
      // Fetch from Supabase
      const { data, error } = await supabase
        .from('furniture_items')
        .select('*');
      
      if (error) {
        throw new Error(error.message);
      }
      
      // If no data, create some sample furniture
      if (!data || data.length === 0) {
        const sampleFurniture = [
          {
            id: 'sample-chair',
            name: 'Modern Chair',
            category: 'Seating',
            model_url: '/models/chair.glb',
            thumbnail_url: 'https://images.pexels.com/photos/586763/pexels-photo-586763.jpeg?auto=compress&cs=tinysrgb&w=400',
            scale: 1.0,
            default_rotation: [0, 0, 0]
          },
          {
            id: 'sample-table',
            name: 'Coffee Table',
            category: 'Tables',
            model_url: '/models/table.glb',
            thumbnail_url: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=400',
            scale: 1.0,
            default_rotation: [0, 0, 0]
          },
          {
            id: 'sample-sofa',
            name: 'Comfortable Sofa',
            category: 'Seating',
            model_url: '/models/sofa.glb',
            thumbnail_url: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=400',
            scale: 1.0,
            default_rotation: [0, 0, 0]
          }
        ];
        set({ catalog: sampleFurniture, isLoading: false });
      } else {
        set({ catalog: data || [], isLoading: false });
      }
    } catch (error) {
      console.error('Error fetching furniture catalog:', error);
      set({ 
        error: error instanceof Error ? error.message : 'Failed to load furniture catalog', 
        isLoading: false 
      });
    }
  },

  addFurniture: (furnitureId: string, position?: [number, number, number]) => {
    const { catalog, placedItems } = get();
    const furniture = catalog.find(item => item.id === furnitureId);
    
    if (!furniture) return;
    
    const newItem: PlacedFurniture = {
      id: `placed-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      furnitureId,
      position: position || [0, 0, -2], // Default position in front of user
      rotation: furniture.default_rotation || [0, 0, 0],
      scale: furniture.scale || 1,
    };
    
    set({ 
      placedItems: [...placedItems, newItem], 
      selectedItemId: newItem.id,
      selectedCatalogItemId: null // Clear catalog selection after placing
    });
  },

  removeFurniture: (placedId: string) => {
    const { placedItems, selectedItemId } = get();
    const newPlacedItems = placedItems.filter(item => item.id !== placedId);
    
    set({ 
      placedItems: newPlacedItems,
      selectedItemId: selectedItemId === placedId ? null : selectedItemId
    });
  },

  updateFurniture: (placedId: string, updates: Partial<PlacedFurniture>) => {
    const { placedItems } = get();
    const newPlacedItems = placedItems.map(item => 
      item.id === placedId ? { ...item, ...updates } : item
    );
    
    set({ placedItems: newPlacedItems });
  },

  selectFurniture: (placedId: string | null) => {
    set({ selectedItemId: placedId });
  },

  selectCatalogItem: (catalogId: string | null) => {
    set({ selectedCatalogItemId: catalogId });
  },

  clearScene: () => {
    set({ placedItems: [], selectedItemId: null });
  },

  saveDesign: async (name: string, thumbnailUrl?: string) => {
    try {
      const { placedItems } = get();
      const user = (await supabase.auth.getUser()).data.user;
      
      if (!user) {
        return { success: false, error: 'User not authenticated' };
      }
      
      const { data, error } = await supabase
        .from('saved_designs')
        .insert({
          name,
          user_id: user.id,
          furniture_data: placedItems,
          thumbnail_url: thumbnailUrl || null,
        })
        .select('id')
        .single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      return { success: true };
    } catch (error) {
      console.error('Error saving design:', error);
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to save design'
      };
    }
  },

  loadDesign: async (designId: string) => {
    try {
      set({ isLoading: true, error: null });
      
      const { data, error } = await supabase
        .from('saved_designs')
        .select('*')
        .eq('id', designId)
        .single();
      
      if (error) {
        throw new Error(error.message);
      }
      
      if (!data) {
        throw new Error('Design not found');
      }
      
      set({ 
        placedItems: data.furniture_data || [],
        selectedItemId: null,
        isLoading: false
      });
      
      return { success: true };
    } catch (error) {
      console.error('Error loading design:', error);
      set({ 
        error: error instanceof Error ? error.message : 'Failed to load design', 
        isLoading: false 
      });
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to load design'
      };
    }
  }
}));